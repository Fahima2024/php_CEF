<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php';
function deleteMessage($id) {
    global $db; // Ensure the $db variable is accessible inside the function
    $stmt = $db->prepare("DELETE FROM messages WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}
function displayMessages() {
    global $db; // Ensure the $db variable is accessible inside the function
    $stmt = $db->query("SELECT * FROM messages ORDER BY created_at DESC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    if (isset($_POST['id'])) {
        deleteMessage($_POST['id']);
    
        header("Location: index.php");
        exit;
    }
}
$messages = displayMessages();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Chat App</title>
    <link rel="stylesheet" href="stlye/style.css">
</head>
<body>
    <h1>Chat Room</h1>
 <div class="message-container">
   
        <?php foreach ($messages as $message): ?>
            <div class="message">
                <p><?= htmlspecialchars($message['message']) ?></p>
                <form action="index.php" method="post">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($message['id']) ?>">
                    <button type="submit">Delete</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
 <div class="form-container">
      
        <form action="messages.php" method="post">
            <textarea name="message" placeholder="Type your message here..."></textarea>
            <button type="submit">Send</button>
        </form>
    </div>
</body>
</html>
