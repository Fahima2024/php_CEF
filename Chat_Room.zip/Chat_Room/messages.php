<?php
include 'db.php';


function sendMessage($message) {
    global $db;
    $stmt = $db->prepare("INSERT INTO messages (message) VALUES (:message)");
    $stmt->bindParam(':message', $message);
    $stmt->execute();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    sendMessage($_POST['message']);
    header("Location: index.php");
    exit;
}
?>
