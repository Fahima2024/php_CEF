<?php
require_once 'Bird.php';

final class Penguin extends Bird {
    private float $swimSpeed;

    public function __construct(string $name, int $age, float $wingSpan, float $swimSpeed) {
        parent::__construct($name, $age, $wingSpan);
        $this->swimSpeed = $swimSpeed;
    }

    public function swim(): string {
        return "Swimming in the water";
    }

    public function makeSound(): string {
        return "Squawk!";
    }

    public function move(): string {
        return $this->swim();
    }


    public function getSwimSpeed(): float {
        return $this->swimSpeed;
    }


    public function setSwimSpeed(float $swimSpeed): void {
        $this->swimSpeed = $swimSpeed;
    }
}
