<?php
require_once 'Bird.php';

class Eagle extends Bird {
    private float $flightSpeed;

    public function __construct(string $name, int $age, float $wingSpan, float $flightSpeed) {
        parent::__construct($name, $age, $wingSpan);
        $this->flightSpeed = $flightSpeed;
    }

    public function hunt(): string {
        return "Hunting prey";
    }

    public function makeSound(): string {
        return "Screech!";
    }

    public function move(): string {
        return "Flying";
    }


    public function getFlightSpeed(): float {
        return $this->flightSpeed;
    }

    public function setFlightSpeed(float $flightSpeed): void {
        $this->flightSpeed = $flightSpeed;
    }
}
