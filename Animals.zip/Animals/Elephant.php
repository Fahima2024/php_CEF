<?php
require_once 'Mammal.php';

class Elephant extends Mammal {
    private float $tuskLength;

    public function __construct(string $name, int $age, string $furColor, float $tuskLength) {
        parent::__construct($name, $age, $furColor);
        $this->tuskLength = $tuskLength;
    }

    public function trumpet(): string {
        return "Trumpet sound!";
    }

    public function makeSound(): string {
        return $this->trumpet();
    }

    public function move(): string {
        return "Walking slowly";
    }


    public function getTuskLength(): float {
        return $this->tuskLength;
    }

   
    public function setTuskLength(float $tuskLength): void {
        $this->tuskLength = $tuskLength;
    }
}
